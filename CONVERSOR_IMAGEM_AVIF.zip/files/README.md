# ⬡ Conversor AVIF

Aplicativo desktop em Python para converter imagens JPG/PNG para o formato **AVIF** — moderno, eficiente e com excelente qualidade.

---

## 📋 Requisitos

- **Python 3.9 ou superior**  
  Download: https://www.python.org/downloads/  
  ⚠️ No Windows, marque **"Add Python to PATH"** durante a instalação.

---

## 🚀 Como usar

### Windows
Dê duplo clique em **`instalar_e_rodar.bat`**  
(na primeira vez instala as dependências e já abre o programa)

### Linux / macOS
```bash
chmod +x instalar_e_rodar.sh
./instalar_e_rodar.sh
```

### Manualmente (qualquer sistema)
```bash
pip install Pillow pillow-avif-plugin
python conversor_avif.py
```

---

## ⚙️ Funcionalidades

| Recurso | Detalhe |
|---|---|
| Formatos de entrada | JPG, JPEG, PNG |
| Formato de saída | AVIF |
| Qualidade | Ajustável de 1 a 100 |
| Velocidade de codificação | Ajustável de 0 (lento/melhor) a 10 (rápido) |
| Conversão em lote | Sim — adicione pastas inteiras |
| Destino personalizado | Salvar na mesma pasta ou escolher outra |
| Não sobrescrever | Pula arquivos já convertidos |
| Manter original | Opcional — pode deletar o arquivo fonte |
| Estatísticas | Total, convertidos, erros e redução média de tamanho |

---

## 📦 Dependências

```
Pillow>=9.1.0
pillow-avif-plugin>=1.4.0
```

---

## ❓ Por que AVIF?

- Até **50% menor** que JPEG na mesma qualidade visual
- Suporte a transparência (como PNG) com compressão melhor
- Suportado pelos principais navegadores e sistemas modernos
- Baseado no codec AV1 (open source, sem royalties)
