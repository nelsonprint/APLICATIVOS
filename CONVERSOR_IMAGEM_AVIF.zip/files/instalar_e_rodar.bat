@echo off
title Conversor AVIF

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERRO] Python nao encontrado!
    echo  Instale em: https://www.python.org/downloads/
    echo  Marque "Add Python to PATH" durante a instalacao.
    pause
    exit /b 1
)

pip install Pillow pillow-avif-plugin >nul 2>&1

start "" pythonw conversor_avif.py
