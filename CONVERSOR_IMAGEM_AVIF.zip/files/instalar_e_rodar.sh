#!/bin/bash

echo ""
echo " ╔══════════════════════════════════════╗"
echo " ║       Conversor AVIF - Setup         ║"
echo " ╚══════════════════════════════════════╝"
echo ""

# Verificar Python
if ! command -v python3 &>/dev/null; then
    echo " [ERRO] Python 3 não encontrado!"
    echo " Instale com: sudo apt install python3 python3-pip  (Ubuntu/Debian)"
    echo "          ou: brew install python3  (macOS)"
    exit 1
fi

echo " [1/2] Instalando dependências..."
pip3 install -r requirements.txt --quiet 2>&1

if [ $? -ne 0 ]; then
    echo " [ERRO] Falha ao instalar. Tente:"
    echo " pip3 install Pillow pillow-avif-plugin"
    exit 1
fi

echo " [2/2] Dependências instaladas!"
echo ""
echo " Iniciando o Conversor AVIF..."
echo ""
python3 conversor_avif.py
