"""
Conversor de Imagens para AVIF
Converte arquivos JPG e PNG para o formato AVIF moderno
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import os
import sys
from pathlib import Path

# --- Verificação de dependências ---
try:
    from PIL import Image
    PIL_OK = True
except ImportError:
    PIL_OK = False

try:
    import pillow_avif  # noqa: F401 - registra o codec AVIF no Pillow
    AVIF_OK = True
except ImportError:
    AVIF_OK = False


# ════════════════════════════════════════════════════════════
#  TEMA E CORES
# ════════════════════════════════════════════════════════════
BG        = "#0f0f13"
BG2       = "#1a1a24"
BG3       = "#22222f"
ACCENT    = "#7c6af7"
ACCENT2   = "#a899ff"
SUCCESS   = "#4ade80"
ERROR     = "#f87171"
WARNING   = "#fbbf24"
FG        = "#e8e6ff"
FG2       = "#9997bb"
BORDER    = "#2e2e42"


class ConversorAVIF(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Conversor AVIF")
        self.geometry("820x640")
        self.minsize(700, 540)
        self.configure(bg=BG)
        self.resizable(True, True)

        # Ícone (texto fallback)
        try:
            self.iconbitmap(default="")
        except Exception:
            pass

        self.arquivos: list[Path] = []
        self.convertendo = False

        self._aplicar_estilos()
        self._construir_ui()
        self._verificar_dependencias()

    # ── Estilos ttk ──────────────────────────────────────────
    def _aplicar_estilos(self):
        s = ttk.Style(self)
        s.theme_use("clam")

        s.configure(".",
                     background=BG, foreground=FG,
                     font=("Segoe UI", 10), borderwidth=0)
        s.configure("TFrame", background=BG)
        s.configure("Card.TFrame", background=BG2)

        s.configure("TLabel", background=BG, foreground=FG)
        s.configure("Sub.TLabel", background=BG2, foreground=FG2, font=("Segoe UI", 9))
        s.configure("Card.TLabel", background=BG2, foreground=FG)
        s.configure("Title.TLabel",
                     background=BG, foreground=FG,
                     font=("Segoe UI", 18, "bold"))
        s.configure("Stat.TLabel",
                     background=BG3, foreground=ACCENT2,
                     font=("Segoe UI", 22, "bold"))
        s.configure("StatSub.TLabel",
                     background=BG3, foreground=FG2,
                     font=("Segoe UI", 9))

        s.configure("Accent.TButton",
                     background=ACCENT, foreground="white",
                     font=("Segoe UI", 10, "bold"),
                     relief="flat", padding=(16, 8))
        s.map("Accent.TButton",
              background=[("active", ACCENT2), ("disabled", BG3)],
              foreground=[("disabled", FG2)])

        s.configure("Ghost.TButton",
                     background=BG3, foreground=FG2,
                     font=("Segoe UI", 9),
                     relief="flat", padding=(12, 6))
        s.map("Ghost.TButton",
              background=[("active", BORDER)],
              foreground=[("active", FG)])

        s.configure("TScale",
                     background=BG2, troughcolor=BG3,
                     sliderthickness=18)

        s.configure("TProgressbar",
                     background=ACCENT, troughcolor=BG3,
                     thickness=6, borderwidth=0)

        s.configure("Treeview",
                     background=BG3, foreground=FG,
                     fieldbackground=BG3, rowheight=28,
                     borderwidth=0, relief="flat")
        s.configure("Treeview.Heading",
                     background=BG2, foreground=FG2,
                     font=("Segoe UI", 9, "bold"), relief="flat")
        s.map("Treeview",
              background=[("selected", ACCENT)],
              foreground=[("selected", "white")])

        s.configure("TCheckbutton",
                     background=BG2, foreground=FG,
                     font=("Segoe UI", 9))
        s.map("TCheckbutton",
              background=[("active", BG2)])

    # ── Layout principal ──────────────────────────────────────
    def _construir_ui(self):
        # ─ Header ─
        hdr = ttk.Frame(self, style="TFrame")
        hdr.pack(fill="x", padx=24, pady=(20, 0))

        ttk.Label(hdr, text="⬡  Conversor AVIF",
                  style="Title.TLabel").pack(side="left")

        self.lbl_status = ttk.Label(hdr, text="", foreground=FG2,
                                    background=BG,
                                    font=("Segoe UI", 9))
        self.lbl_status.pack(side="right", padx=4)

        tk.Frame(self, height=1, bg=BORDER).pack(fill="x",
                                                  padx=24, pady=12)

        # ─ Corpo ─
        corpo = ttk.Frame(self)
        corpo.pack(fill="both", expand=True, padx=24)
        corpo.columnconfigure(0, weight=3)
        corpo.columnconfigure(1, weight=1)
        corpo.rowconfigure(0, weight=1)

        self._construir_painel_esquerdo(corpo)
        self._construir_painel_direito(corpo)

        # ─ Barra inferior ─
        self._construir_barra_inferior()

    def _construir_painel_esquerdo(self, pai):
        esq = ttk.Frame(pai)
        esq.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        esq.rowconfigure(1, weight=1)
        esq.columnconfigure(0, weight=1)

        # Botões de ação
        btn_row = ttk.Frame(esq)
        btn_row.grid(row=0, column=0, sticky="ew", pady=(0, 8))

        ttk.Button(btn_row, text="＋  Adicionar Imagens",
                   style="Accent.TButton",
                   command=self._adicionar_arquivos).pack(side="left", padx=(0, 8))
        ttk.Button(btn_row, text="📁  Adicionar Pasta",
                   style="Ghost.TButton",
                   command=self._adicionar_pasta).pack(side="left", padx=(0, 8))
        ttk.Button(btn_row, text="✕  Remover Selecionados",
                   style="Ghost.TButton",
                   command=self._remover_selecionados).pack(side="left")
        ttk.Button(btn_row, text="Limpar",
                   style="Ghost.TButton",
                   command=self._limpar_lista).pack(side="right")

        # Área de drop / lista
        self._construir_lista(esq)

    def _construir_lista(self, pai):
        container = tk.Frame(pai, bg=BG3, bd=0)
        container.grid(row=1, column=0, sticky="nsew")
        container.rowconfigure(0, weight=1)
        container.columnconfigure(0, weight=1)

        cols = ("arquivo", "tamanho", "status")
        self.tree = ttk.Treeview(container, columns=cols,
                                  show="headings", selectmode="extended")
        self.tree.heading("arquivo", text="Arquivo")
        self.tree.heading("tamanho", text="Tamanho")
        self.tree.heading("status", text="Status")
        self.tree.column("arquivo", width=340, stretch=True)
        self.tree.column("tamanho", width=80, anchor="e", stretch=False)
        self.tree.column("status", width=120, anchor="center", stretch=False)

        vsb = ttk.Scrollbar(container, orient="vertical",
                             command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")

        # Tag de cores para status
        self.tree.tag_configure("ok",      foreground=SUCCESS)
        self.tree.tag_configure("erro",    foreground=ERROR)
        self.tree.tag_configure("pulado",  foreground=WARNING)
        self.tree.tag_configure("default", foreground=FG)

        # Mensagem de placeholder
        self.lbl_drop = tk.Label(container,
                                  text="Arraste imagens ou use os botões acima\n"
                                       "JPG · JPEG · PNG são suportados",
                                  bg=BG3, fg=FG2,
                                  font=("Segoe UI", 11))
        self.lbl_drop.place(relx=0.5, rely=0.5, anchor="center")

    def _construir_painel_direito(self, pai):
        dir_ = ttk.Frame(pai, style="Card.TFrame")
        dir_.grid(row=0, column=1, sticky="nsew")
        dir_.columnconfigure(0, weight=1)

        pad = {"padx": 16}

        ttk.Label(dir_, text="Configurações",
                  style="Card.TLabel",
                  font=("Segoe UI", 11, "bold")).pack(anchor="w",
                                                       padx=16, pady=(16, 12))

        # Qualidade
        ttk.Label(dir_, text="Qualidade AVIF",
                  style="Sub.TLabel").pack(anchor="w", **pad)
        self.var_qualidade = tk.IntVar(value=75)
        row_q = ttk.Frame(dir_, style="Card.TFrame")
        row_q.pack(fill="x", padx=16, pady=(4, 0))
        self.lbl_q = ttk.Label(row_q, text="75", style="Card.TLabel",
                                font=("Segoe UI", 12, "bold"),
                                foreground=ACCENT2, background=BG2,
                                width=4)
        self.lbl_q.pack(side="right")
        ttk.Scale(row_q, from_=1, to=100,
                  variable=self.var_qualidade,
                  orient="horizontal",
                  command=self._atualizar_label_q).pack(side="left",
                                                         fill="x",
                                                         expand=True)

        ttk.Label(dir_,
                  text="Menor ← → Maior qualidade",
                  style="Sub.TLabel",
                  font=("Segoe UI", 8)).pack(anchor="w", padx=16, pady=(2, 12))

        self._separador(dir_)

        # Velocidade de codificação
        ttk.Label(dir_, text="Velocidade (Speed)",
                  style="Sub.TLabel").pack(anchor="w", **pad, pady=(8, 0))
        self.var_speed = tk.IntVar(value=6)
        row_s = ttk.Frame(dir_, style="Card.TFrame")
        row_s.pack(fill="x", padx=16, pady=(4, 0))
        self.lbl_s = ttk.Label(row_s, text="6", style="Card.TLabel",
                                font=("Segoe UI", 12, "bold"),
                                foreground=ACCENT2, background=BG2,
                                width=4)
        self.lbl_s.pack(side="right")
        ttk.Scale(row_s, from_=0, to=10,
                  variable=self.var_speed,
                  orient="horizontal",
                  command=self._atualizar_label_s).pack(side="left",
                                                         fill="x",
                                                         expand=True)
        ttk.Label(dir_, text="Lento ← → Rápido",
                  style="Sub.TLabel",
                  font=("Segoe UI", 8)).pack(anchor="w", padx=16, pady=(2, 12))

        self._separador(dir_)

        # Destino
        ttk.Label(dir_, text="Pasta de destino",
                  style="Sub.TLabel").pack(anchor="w", **pad, pady=(8, 4))
        self.var_dest = tk.StringVar(value="Mesma pasta")
        dest_row = ttk.Frame(dir_, style="Card.TFrame")
        dest_row.pack(fill="x", padx=16)
        self.ent_dest = tk.Entry(dest_row, textvariable=self.var_dest,
                                  bg=BG3, fg=FG2,
                                  insertbackground=FG,
                                  relief="flat", font=("Segoe UI", 8),
                                  state="readonly")
        self.ent_dest.pack(side="left", fill="x", expand=True,
                            ipady=4, padx=(0, 6))
        ttk.Button(dest_row, text="…", style="Ghost.TButton",
                   command=self._escolher_destino,
                   width=3).pack(side="right")

        self._separador(dir_)

        # Opções
        ttk.Label(dir_, text="Opções",
                  style="Sub.TLabel").pack(anchor="w", **pad, pady=(8, 4))
        self.var_sobrescrever = tk.BooleanVar(value=False)
        ttk.Checkbutton(dir_, text="Sobrescrever existentes",
                         variable=self.var_sobrescrever,
                         style="TCheckbutton").pack(anchor="w", padx=16)

        self.var_manter_original = tk.BooleanVar(value=True)
        ttk.Checkbutton(dir_, text="Manter arquivo original",
                         variable=self.var_manter_original,
                         style="TCheckbutton").pack(anchor="w", padx=16, pady=(4, 0))

        # Estatísticas
        self._construir_stats(dir_)

    def _construir_stats(self, pai):
        self._separador(pai)
        ttk.Label(pai, text="Estatísticas",
                  style="Sub.TLabel").pack(anchor="w", padx=16, pady=(8, 6))

        stats = ttk.Frame(pai, style="Card.TFrame")
        stats.pack(fill="x", padx=16, pady=(0, 12))
        stats.columnconfigure(0, weight=1)
        stats.columnconfigure(1, weight=1)

        def bloco(pai, row, col, var, label):
            f = tk.Frame(pai, bg=BG3)
            f.grid(row=row, column=col, padx=3, pady=3, sticky="ew")
            tk.Label(f, textvariable=var, bg=BG3,
                     fg=ACCENT2,
                     font=("Segoe UI", 20, "bold")).pack(pady=(6, 0))
            tk.Label(f, text=label, bg=BG3, fg=FG2,
                     font=("Segoe UI", 8)).pack(pady=(0, 6))

        self.var_total   = tk.StringVar(value="0")
        self.var_ok      = tk.StringVar(value="0")
        self.var_erro    = tk.StringVar(value="0")
        self.var_reducao = tk.StringVar(value="—")

        bloco(stats, 0, 0, self.var_total,   "Total")
        bloco(stats, 0, 1, self.var_ok,      "Convertidos")
        bloco(stats, 1, 0, self.var_erro,    "Erros")
        bloco(stats, 1, 1, self.var_reducao, "Redução média")

    def _construir_barra_inferior(self):
        tk.Frame(self, height=1, bg=BORDER).pack(fill="x", padx=24, pady=(12, 0))

        bot = ttk.Frame(self)
        bot.pack(fill="x", padx=24, pady=(8, 16))

        self.prog = ttk.Progressbar(bot, style="TProgressbar",
                                     mode="determinate")
        self.prog.pack(fill="x", pady=(0, 8))

        btn_row = ttk.Frame(bot)
        btn_row.pack(fill="x")

        self.lbl_prog = ttk.Label(btn_row, text="Pronto",
                                   foreground=FG2, background=BG,
                                   font=("Segoe UI", 9))
        self.lbl_prog.pack(side="left")

        self.btn_converter = ttk.Button(btn_row,
                                         text="▶  Converter Tudo",
                                         style="Accent.TButton",
                                         command=self._iniciar_conversao)
        self.btn_converter.pack(side="right")

    def _separador(self, pai):
        tk.Frame(pai, height=1, bg=BORDER).pack(fill="x", padx=12, pady=4)

    # ── Verificação de dependências ───────────────────────────
    def _verificar_dependencias(self):
        msgs = []
        if not PIL_OK:
            msgs.append("• Pillow não instalado  →  pip install Pillow")
        if not AVIF_OK:
            msgs.append("• pillow-avif-plugin não instalado  →  pip install pillow-avif-plugin")

        if msgs:
            messagebox.showerror(
                "Dependências ausentes",
                "Instale as bibliotecas necessárias e reinicie:\n\n" +
                "\n".join(msgs) +
                "\n\nOu execute:  pip install Pillow pillow-avif-plugin"
            )
            self.btn_converter.state(["disabled"])
            self.lbl_status.config(text="⚠  Dependências faltando", foreground=ERROR)
        else:
            self.lbl_status.config(text="✓  Pronto para converter", foreground=SUCCESS)

    # ── Gerenciamento de arquivos ─────────────────────────────
    def _adicionar_arquivos(self):
        paths = filedialog.askopenfilenames(
            title="Selecionar imagens",
            filetypes=[
                ("Imagens", "*.jpg *.jpeg *.png"),
                ("JPEG", "*.jpg *.jpeg"),
                ("PNG", "*.png"),
                ("Todos", "*.*"),
            ]
        )
        self._inserir_paths(paths)

    def _adicionar_pasta(self):
        pasta = filedialog.askdirectory(title="Selecionar pasta")
        if not pasta:
            return
        paths = []
        for ext in ("*.jpg", "*.jpeg", "*.png",
                    "*.JPG", "*.JPEG", "*.PNG"):
            paths += list(Path(pasta).glob(ext))
        self._inserir_paths([str(p) for p in paths])

    def _inserir_paths(self, paths):
        existentes = {str(p) for p in self.arquivos}
        novos = 0
        for p in paths:
            path = Path(p)
            if str(path) not in existentes and path.suffix.lower() in \
                    (".jpg", ".jpeg", ".png"):
                self.arquivos.append(path)
                existentes.add(str(path))
                self._adicionar_linha(path)
                novos += 1
        self._atualizar_stats()
        if novos:
            self.lbl_drop.place_forget()

    def _adicionar_linha(self, path: Path, status="—", tag="default"):
        try:
            tam = path.stat().st_size
            tam_str = self._formatar_tamanho(tam)
        except Exception:
            tam_str = "?"
        self.tree.insert("", "end",
                          iid=str(path),
                          values=(path.name, tam_str, status),
                          tags=(tag,))

    def _remover_selecionados(self):
        sel = self.tree.selection()
        for iid in sel:
            self.tree.delete(iid)
            self.arquivos = [p for p in self.arquivos if str(p) != iid]
        if not self.arquivos:
            self.lbl_drop.place(relx=0.5, rely=0.5, anchor="center")
        self._atualizar_stats()

    def _limpar_lista(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.arquivos.clear()
        self.lbl_drop.place(relx=0.5, rely=0.5, anchor="center")
        self._atualizar_stats()

    def _escolher_destino(self):
        pasta = filedialog.askdirectory(title="Pasta de destino")
        if pasta:
            self.var_dest.set(pasta)

    # ── Conversão ─────────────────────────────────────────────
    def _iniciar_conversao(self):
        if not self.arquivos:
            messagebox.showwarning("Atenção", "Adicione pelo menos uma imagem.")
            return
        if self.convertendo:
            return
        self.convertendo = True
        self.btn_converter.state(["disabled"])
        self._resetar_status()
        threading.Thread(target=self._executar_conversao,
                          daemon=True).start()

    def _resetar_status(self):
        for iid in self.tree.get_children():
            vals = list(self.tree.item(iid, "values"))
            vals[2] = "Aguardando…"
            self.tree.item(iid, values=vals, tags=("default",))

    def _executar_conversao(self):
        total = len(self.arquivos)
        ok = 0
        erros = 0
        reducoes: list[float] = []

        dest_str = self.var_dest.get()
        qualidade = self.var_qualidade.get()
        speed     = self.var_speed.get()
        sobrescrever = self.var_sobrescrever.get()

        for i, src in enumerate(self.arquivos):
            self.after(0, self._atualizar_progresso,
                       i, total, f"Convertendo: {src.name}")

            # Destino
            if dest_str == "Mesma pasta":
                dest_dir = src.parent
            else:
                dest_dir = Path(dest_str)
                dest_dir.mkdir(parents=True, exist_ok=True)

            dest = dest_dir / (src.stem + ".avif")

            if dest.exists() and not sobrescrever:
                self.after(0, self._marcar_linha, str(src),
                           "⟳ Já existe", "pulado")
                continue

            try:
                self._converter_arquivo(src, dest, qualidade, speed)
                tam_orig = src.stat().st_size
                tam_novo = dest.stat().st_size
                reducao = (1 - tam_novo / tam_orig) * 100 if tam_orig > 0 else 0
                reducoes.append(reducao)
                label = f"✓ −{reducao:.0f}%"
                self.after(0, self._marcar_linha, str(src), label, "ok")

                if not self.var_manter_original.get():
                    src.unlink(missing_ok=True)

                ok += 1
            except Exception as exc:
                erros += 1
                self.after(0, self._marcar_linha, str(src),
                           f"✕ {str(exc)[:30]}", "erro")

        reducao_media = (sum(reducoes) / len(reducoes)) if reducoes else 0
        self.after(0, self._finalizar, total, ok, erros, reducao_media)

    def _converter_arquivo(self, src: Path, dest: Path,
                            qualidade: int, speed: int):
        from PIL import Image  # garantido disponível aqui
        img = Image.open(src)

        # AVIF precisa de RGB ou RGBA
        if img.mode not in ("RGB", "RGBA"):
            img = img.convert("RGB")

        # pillow-avif-plugin usa qmin/qmax ou quality dependendo da versão
        # quality: 0=pior, 100=melhor (inverso do qp do AV1)
        try:
            img.save(dest, format="AVIF",
                     quality=qualidade,
                     speed=speed)
        except TypeError:
            # Versão antiga: tenta sem parâmetros extra
            img.save(dest, format="AVIF")

    # ── UI helpers ────────────────────────────────────────────
    def _marcar_linha(self, iid: str, status: str, tag: str):
        if self.tree.exists(iid):
            vals = list(self.tree.item(iid, "values"))
            vals[2] = status
            self.tree.item(iid, values=vals, tags=(tag,))

    def _atualizar_progresso(self, atual, total, msg):
        pct = int(atual / total * 100) if total else 0
        self.prog["value"] = pct
        self.lbl_prog.config(text=f"{msg}  ({atual}/{total})")

    def _finalizar(self, total, ok, erros, reducao_media):
        self.prog["value"] = 100
        self.lbl_prog.config(
            text=f"Concluído — {ok} convertidos, {erros} erros"
        )
        self.var_ok.set(str(ok))
        self.var_erro.set(str(erros))
        self.var_reducao.set(f"{reducao_media:.0f}%" if reducao_media else "—")
        self.lbl_status.config(
            text=f"✓ Conversão concluída  ·  {ok}/{total} arquivos",
            foreground=SUCCESS if erros == 0 else WARNING
        )
        self.btn_converter.state(["!disabled"])
        self.convertendo = False

    def _atualizar_stats(self):
        self.var_total.set(str(len(self.arquivos)))

    def _atualizar_label_q(self, _=None):
        self.lbl_q.config(text=str(self.var_qualidade.get()))

    def _atualizar_label_s(self, _=None):
        self.lbl_s.config(text=str(self.var_speed.get()))

    @staticmethod
    def _formatar_tamanho(bytes_: int) -> str:
        for unit in ("B", "KB", "MB", "GB"):
            if bytes_ < 1024:
                return f"{bytes_:.0f} {unit}"
            bytes_ /= 1024
        return f"{bytes_:.1f} GB"


# ════════════════════════════════════════════════════════════
#  ENTRY POINT
# ════════════════════════════════════════════════════════════
if __name__ == "__main__":
    app = ConversorAVIF()
    app.mainloop()
